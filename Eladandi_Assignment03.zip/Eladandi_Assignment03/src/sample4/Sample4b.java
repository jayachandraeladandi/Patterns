package sample4;

public class Sample4b extends Sample4a{
	    // This is a new method and not an override of the privateMethod in superclass
	    private static void privateMethod() {
	        System.out.println("This is a private method in subclass.");
	    }
	    
	    // This is a new method and not an override of the publicMethod in superclass
	    public static void publicMethod() {
	        System.out.println("This is a public method in subclass.");
	    }

}
