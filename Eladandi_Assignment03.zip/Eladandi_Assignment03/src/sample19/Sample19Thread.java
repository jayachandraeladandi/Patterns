package sample19;

public class Sample19Thread extends Thread {
	    public void run() {
	        System.out.println("Thread is running.");
	    }
	    
	    public class MyRunnable implements Runnable {
	        public void run() {
	            System.out.println("Thread is running.");
	        }
	    }
    public static void main(String args[]) {
	// Creating and starting a thread object
	Sample19Thread myThread = new Sample19Thread();
	myThread.start();
	Sample19Thread myRunnable = new Sample19Thread();
	Thread myThread1 = new Thread(myRunnable);
	myThread1.start();

    }
}
