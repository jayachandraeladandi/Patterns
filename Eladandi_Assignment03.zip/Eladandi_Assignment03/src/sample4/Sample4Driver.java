package sample4;

public class Sample4Driver {
	    public static void main(String[] args) {
	        Sample4a.publicMethod(); // Output: This is a public method in superclass.
	        Sample4b.publicMethod(); // Output: This is a public method in subclass.

	       // Sample4a.privateMethod(); // Error: The method privateMethod() from the type Superclass is not visible
	        //Sample4b.privateMethod(); // Error: The method privateMethod() from the type Subclass is not visible
	    }
}
