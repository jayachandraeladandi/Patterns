package sample3;

public class Sample3 {
	    public Sample3 draw() {
	        System.out.println("Drawing shape...");
	        return new Sample3();
	    }
	}

	class Circle extends Sample3 {
	    @Override
	    public Circle draw() {
	        System.out.println("Drawing circle...");
	        return new Circle();
	    }
	}

	class Rectangle extends Sample3 {
	    @Override
	    public Rectangle draw() {
	        System.out.println("Drawing rectangle...");
	        return new Rectangle();
	    }
	}


