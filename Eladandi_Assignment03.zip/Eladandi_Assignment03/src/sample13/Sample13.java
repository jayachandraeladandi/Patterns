package sample13;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class Sample13 {
	public static void main (String[] args) {
        ArrayList<String> arr = new ArrayList<String>();
        arr.add("Eladandi");
        arr.add("Jaya");
        arr.add("Chandra");
        arr.add("Sai");
        System.out.println("ArrayList elements are:");
        Iterator it = arr.iterator();
        while (it.hasNext())
            System.out.println(it.next());
  
        Vector<String> arr2 = new Vector<String>();
        arr2.addElement("Eladandi");
        arr2.addElement("Jaya");
        arr2.addElement("surya");
        arr2.addElement("sai");
        System.out.println("\nVector elements are:");
        Enumeration<String> e = arr2.elements();
        while (e.hasMoreElements())
           System.out.println(e.nextElement());
    }

}
