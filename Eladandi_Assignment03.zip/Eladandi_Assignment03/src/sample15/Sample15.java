package sample15;

import java.util.HashMap;
import java.util.Hashtable;

public class Sample15 {
	    public static void main(String[] args) {
	        Hashtable<String, Integer> actors = new Hashtable<>();
	        actors.put("Surya", 33);
	        actors.put("Mahesh", 38);
	        actors.put("Nithin", 34);

	        for (String name : actors.keySet()) {
	            int age = actors.get(name);
	            System.out.println(name + "'s age is: " + age);
	        }
	        System.out.println("Using HashMap");
	    HashMap<String, Integer> actors = new HashMap<>();
	    actors.put("Vijay", 33);
        actors.put("Sharukh", 38);
        actors.put("Salman", 34);

        for (String name : actors.keySet()) {
            int age = actors.get(name);
            System.out.println(name + "'s age is: " + age);
        }
	 }  

}
