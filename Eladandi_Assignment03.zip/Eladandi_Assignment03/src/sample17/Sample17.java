package sample17;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;


public class Sample17 {
	public static void main(String[] args) {
	
	List<Integer> l1 = new CopyOnWriteArrayList<>();
	l1.add(1);
	l1.add(2);
	l1.add(3);

	Iterator<Integer> iterator = l1.iterator();

	while (iterator.hasNext()) {
	    Integer value = iterator.next();
	    System.out.println(value);
	    l1.remove(value); // modification during iteration
	}
	List<Integer> ab = new ArrayList<>();
	ab.add(1);
	ab.add(2);
	ab.add(3);

	Iterator<Integer> itr = ab.iterator();

	while (itr.hasNext()) {
	    Integer value = itr.next();
	    System.out.println(value);
	    ab.remove(value); // modification during iteration
	}
	
  }
	
}
