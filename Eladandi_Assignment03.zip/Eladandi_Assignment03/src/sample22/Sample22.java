package sample22;

public class Sample22 {

	public static void main(String args[]) {
		String st1="Eladandi";
		String st2="JayaChandra "+st1;
		System.out.println(st2);
		System.out.println(st1);
		
		
	}
}
