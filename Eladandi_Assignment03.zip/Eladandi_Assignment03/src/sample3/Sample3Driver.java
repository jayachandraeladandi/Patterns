package sample3;

public class Sample3Driver {

	public static void main(String[] args) {
		        Sample3 shape = new Sample3();
		        Circle circle = new Circle();
		        Rectangle rectangle = new Rectangle();

		        Sample3 newShape = shape.draw(); // returns a Shape
		        Sample3 newCircle = circle.draw(); // returns a Circle
		        Sample3 newRectangle = rectangle.draw(); // returns a Rectangle

		        System.out.println(newShape.getClass()); // prints "class Shape"
		        System.out.println(newCircle.getClass()); // prints "class Circle"
		        System.out.println(newRectangle.getClass()); // prints "class Rectangle"
		    }
}
