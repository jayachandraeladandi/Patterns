package sample18;

public class Sample18 extends Thread{
	    public void run() {
	        System.out.println("Thread is running...");
	    }

	    public static void main(String[] args) {
	        Sample18 ss = new Sample18();

	        ss.start(); // First time thread is started

	        try {
	            ss.join(); // Wait for thread to finish
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	        // Trying to start the same thread object again will result in an IllegalThreadStateException
	        ss.start(); // Second time thread is started - will throw an exception
	    }
}
