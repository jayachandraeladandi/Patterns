package sample1;

public class Sample1Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample1<Integer> sc = new Sample1<>(10);
		sc.setData(20);
		System.out.println(sc.getData());
	}

}
