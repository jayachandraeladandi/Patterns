package sample4;

public class Sample4a {
		    private static void privateMethod() {
		        System.out.println("This is a private method in superclass.");
		    }
		    
		    public static void publicMethod() {
		        System.out.println("This is a public method in superclass.");
		    }

}
