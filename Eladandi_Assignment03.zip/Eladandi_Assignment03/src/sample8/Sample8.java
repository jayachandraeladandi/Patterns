package sample8;

public class Sample8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("This is try Block");
			  throw new NullPointerException();
		}
		finally {
			System.out.println("This is finally block");
		}

	}

}
