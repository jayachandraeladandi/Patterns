package sample5;

public class Sample5 {
	    public static void main(String[] args){  
	        StringBuffer str=new StringBuffer("hello");  
	        str.append("java");  
	        System.out.println(str);  
	        System.out.println(System.nanoTime());
	        
	        StringBuilder builder=new StringBuilder("hello");  
	        builder.append("java");  
	        System.out.println(builder);  
	        System.out.println(System.nanoTime());
	    }   
}
