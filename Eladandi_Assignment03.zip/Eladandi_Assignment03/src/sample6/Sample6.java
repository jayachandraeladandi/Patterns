package sample6;

public class Sample6 {
	
	public static void main(String[] args) 
    { 
        String str1 = "Kohli";
        String str2 =  "Virat"+str1;
        System.out.println(str2);
        System.out.println(System.nanoTime());
        
        StringBuffer buffer=new StringBuffer("Virat");  
        buffer.append("Kohli");  
        System.out.println(buffer);  
        System.out.println(System.nanoTime());
        
    }
}
