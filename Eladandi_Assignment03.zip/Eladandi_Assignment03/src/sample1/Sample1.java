package sample1;

public class Sample1<T> {
		   private T data;

		   public Sample1(T data) {
		      this.data = data;
		   }

		   public T getData() {
		      return this.data;
		   }

		   public void setData(T data) {
		      this.data = data;
		   }
}
